package com.deitel.doodlz;

import android.view.MotionEvent;

public interface ITouchMovedHandler
{
    void onTouchMoved(MotionEvent event);
}
