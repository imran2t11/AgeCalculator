package com.deitel.doodlz;

public interface ITouchEndedHandler
{
    void onTouchEnded(int lineId);
}
