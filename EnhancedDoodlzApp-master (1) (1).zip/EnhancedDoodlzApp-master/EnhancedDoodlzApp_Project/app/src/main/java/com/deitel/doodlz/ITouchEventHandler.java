package com.deitel.doodlz;

import android.view.MotionEvent;

public interface ITouchEventHandler
{
    boolean onTouchEvent(MotionEvent event);
}
