package com.deitel.doodlz;

public interface ITouchStartedHandler
{
    void onTouchStarted(float x, float y, int lineId);
}
