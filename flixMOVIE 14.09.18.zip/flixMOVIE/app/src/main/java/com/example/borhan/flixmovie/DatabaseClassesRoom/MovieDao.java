package com.example.borhan.flixmovie.DatabaseClassesRoom;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;
@Dao
public interface MovieDao {
    @Insert
    public void addMovie(MovieModel movieModel) ;




    @Query("Select * from Movies")
    public List<MovieModel> getmovieList();

    @Update
    public void updateMovie(MovieModel movieModel);

    @Delete
    public void DeleteMovie(MovieModel movieModel);
}
