# movies-room

Example Android application with database which uses [Room](https://developer.android.com/topic/libraries/architecture/room.html) persistant storage and [ViewModel](https://developer.android.com/topic/libraries/architecture/viewmodel.html) with [LiveData](https://developer.android.com/topic/libraries/architecture/livedata.html)  from Android Architecture Components.

![Screenshots](https://image.ibb.co/mm3ex7/movies_screenshot.png)
