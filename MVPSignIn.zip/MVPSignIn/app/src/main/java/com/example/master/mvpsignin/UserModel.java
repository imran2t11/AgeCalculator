package com.example.master.mvpsignin;

public class UserModel {
    String username;

}
